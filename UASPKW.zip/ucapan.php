<!DOCTYPE HTML>
<html>
	<head>
		<title>Berhasil Login</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="css/main.css" />
		<noscript><link rel="stylesheet" href="css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">
		<div id="wrapper">
			<div id="bg"></div>
			<div id="overlay"></div>
			<div id="main">

				<!-- Header -->
					<header id="header">
						<h1>Selamat Datang :D</h1>
                        <marquee width="500" height="40">Silahkan klik tombol lingkaran untuk memulai</marquee>
						<p>Toko Buku &nbsp;&bull;&nbsp; Danisa Rahadian A &nbsp;&bull;&nbsp; Based in Indonesia</p>
						<nav>
							<ul>
								<li><a href="home.php" class="icon brands fa-facebook-f"><span class="label">Mulai</span></a></li>
							</ul>
						</nav>
					</header>

				<!-- Footer -->
					<footer id="footer">
						<span class="copyright">&copy; All right Reserved |<a href="https://www.instagram.com/danisarahadians/"> Danisa Rahadian A</a>.</span>
					</footer>

			</div>
		</div>
		<script>
			window.onload = function() { document.body.classList.remove('is-preload'); }
			window.ontouchmove = function() { return false; }
			window.onorientationchange = function() { document.body.scrollTop = 0; }
		</script>
	</body>
</html>