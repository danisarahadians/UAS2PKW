<?php
//koneksi database
include './config.php';

//Menangkap data id yang di kirim dari url karena delete cuma membutuhkan id
$id = $_GET['id'];

//Menghapus data dari database
mysqli_query($koneksi, "delete from tokobuku where id='$id'");

// Mengalihkan halaman kembali ke home.php
header("location:home.php");